﻿// Models/TodoItem.cs
using Microsoft.EntityFrameworkCore;

namespace TodoListApp.Models
{
    public class TodoItem
    {
        public int Id { get; set; }
        public string Task { get; set; }
        public bool IsComplete { get; set; }
    }
}



